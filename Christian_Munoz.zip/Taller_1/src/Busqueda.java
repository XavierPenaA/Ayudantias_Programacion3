import java.util.Scanner;

public class Busqueda {
    Scanner entrada = new Scanner(System.in);
    int op;

    public void busqueda() {
        String[] frases = {"Hola Juan, como estas?", "5 manzanas y 3 peras", "Esta cadena no tiene numeros"};
        String[] array = {"Manzana", "Pera", "Sandia", "Banana", "Tomate", "Limon", "Mandarina", "Naranja"};
        do {
            System.out.println("1. Ingresar una letra para buscar el numero de coincidencias");
            System.out.println("2. Ingresar una palabra para buscar el numero de coincidencias");
            System.out.println("3. Ingresar un termino para generar un array que lo contenga");
            System.out.println("4. Salir al menu principal");
            op = entrada.nextInt();
            entrada.nextLine(); // Consume the leftover newline after nextInt()

            switch (op) {
                case 1:
                    busquedaChar(frases);
                    break;

                case 2:
                    busquedaString(frases);
                    break;
                case 3:
                    String[] subArray = busquedaSubArray(array);
                    for (int i = 0; i < subArray.length; i++) {
                        System.out.println(subArray[i]);
                    }
                    break;
                case 4:
                    System.out.println("Volviendo al menu principal");
                    break;

                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
                    break;
            }
        } while (op != 4);
    }

    public void busquedaChar(String[] frases) {
        System.out.println("Ingrese la letra: ");
        char letra = entrada.nextLine().charAt(0);

        char[] cantidadLetras;
        int coincidencias = 0;
        for (int i = 0; i < frases.length; i++) {
            cantidadLetras = frases[i].toCharArray();
            for (int j = 0; j < frases[i].length(); j++) {
                if (cantidadLetras[j] == letra) {
                    coincidencias++;
                }
            }

            if (coincidencias > 0) {
                System.out.println("Se encontraron " + coincidencias + " coincidencias en la frase: " + frases[i]);
                coincidencias = 0; // Reset coincidencias for the next phrase
            }
        }
        System.out.println(" ");
    }

    public void busquedaString(String[] frases) {
        System.out.println("Ingrese la palabra a buscar: ");
        String palabra = entrada.nextLine();
        int coincidencias;

        for (int i = 0; i < frases.length; i++) {
            coincidencias = 0;
            String fraseLimpia = frases[i].replaceAll("[^a-zA-Z0-9 ]", "");  // Remove punctuation and convert to lowercase
            String[] palabrasEnFrase = fraseLimpia.split(" ");
            for (int j = 0; j < palabrasEnFrase.length; j++) {
                if (palabra.equalsIgnoreCase(palabrasEnFrase[j])) {
                    coincidencias++;
                }
            }

            if (coincidencias > 0) {
                System.out.println("Se encontró la palabra '" + palabra + "' en la frase: " + frases[i]);
            }

        }

    }

    public String[] busquedaSubArray(String[] array) {
        System.out.println("Ingrese el término a buscar: ");
        String termino = entrada.nextLine().toLowerCase();  // Leer el término y convertirlo a minúsculas
        int coincidencias = 0;
        int[] lugar = new int[array.length];  // Arreglo para almacenar los índices de las coincidencias

        // Buscar coincidencias
        for (int i = 0; i < array.length; i++) {
            String arrayLimpio = array[i].toLowerCase().replaceAll("[^a-zA-Z0-9 ]", "");  // Limpiar palabra y convertir a minúsculas
            if (arrayLimpio.contains(termino)) {  // Buscar coincidencias
                lugar[coincidencias] = i;  // Guardar el índice donde se encuentra la coincidencia
                coincidencias++;
            }
        }

        // Crear subArray con las coincidencias
        String[] subArray = new String[coincidencias];
        for (int i = 0; i < coincidencias; i++) {
            subArray[i] = array[lugar[i]];  // Llenar el subArray con los elementos coincidentes
        }

        // Si no se encontraron coincidencias
        if (coincidencias == 0) {
            System.out.println("No se encontró el término");
        }

        return subArray;  // Devolver el subArray con las coincidencias o vacío si no hay
    }

}

