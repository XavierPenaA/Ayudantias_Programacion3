import java.util.Scanner;

public class Menu {
    Scanner entrada = new Scanner(System.in);
    Busqueda search = new Busqueda();
    ManipulacionStrings manipulacion = new ManipulacionStrings();
    Ordenamiento ordenamiento = new Ordenamiento();
    public void menuPrincipal() {
        int op;
        do {
            System.out.println("Menu Principal");
            System.out.println("1. Busqueda de Strings");
            System.out.println("2. Manipulacion de Strings");
            System.out.println("3. Ordenamineto de Strings");
            System.out.println("4. Salir");
            op = entrada.nextInt();
            switch (op) {
                case 1:
                    search.busqueda();
                    break;
                case 2:
                    manipulacion.manipulacion();
                    break;
                case 3:
                    ordenamiento.ordenar();
                    break;
                case 4:
                    System.out.println("Saliendo del programa");
                    break;
            }

        } while (op != 4);
    }
}
