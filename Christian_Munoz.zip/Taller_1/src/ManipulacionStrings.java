import java.util.Scanner;

public class ManipulacionStrings {
    Scanner entrada = new Scanner(System.in);

    public void manipulacion() {
        int opcion;
        String frase = "juan tiene una bicicleta y juan tiene un coche, pero juan no tiene miedo.";
        do {
            System.out.println("1. Eliminar letra de un array");
            System.out.println("2. Eliminar una palabra de un array");
            System.out.println("3. Separar cada palabra de un array");
            System.out.println("4: Salir al menu principal");
            opcion = entrada.nextInt();
            switch (opcion) {
                case 1:
                    deleteChar(frase);
                    break;
                case 2:
                    deleteString(frase);
                    break;
                case 3:
                    separarPalabras(frase);
                    break;
                case 4:
                    System.out.println("Saliendo al menu principal");
                    break;
            }
        } while (opcion != 4);
    }

    public void deleteChar(String frase) {
        System.out.println("Ingrese la letra que desea eliminar:");
        entrada.nextLine();
        char letra = entrada.nextLine().charAt(0);
        // Eliminar todas las ocurrencias de la letra especificada
        String fraseModificada = frase.replace(Character.toString(letra), "");

        // Mostrar la frase resultante
        System.out.println("Frase original: " + frase);
        System.out.println("Frase modificada: " + fraseModificada);

    }
    public void deleteString(String frase) {
        System.out.println("Ingrese la palabra que desea eliminar:");
        entrada.nextLine();
        String palabra = entrada.nextLine();

        System.out.println("Eliminacion de la palabra "+ palabra+" en toda la frase o oracion");
        String fraseModificada = frase.replace(palabra, "");
        System.out.println("Frase original: " + frase);
        System.out.println("Frase modificada: " + fraseModificada);

        // Encontrar la primera aparición de la palabra
        int index = frase.indexOf(palabra);

        if (index != -1) {
            // Crear una nueva cadena sin la palabra en la primera aparición
            String fraseModificada2 = frase.substring(0, index) +
                    frase.substring(index + palabra.length());

            // Mostrar la frase resultante
            System.out.println("Eliminacion de la palabra "+ palabra+" solo en la primera aparicion");
            System.out.println("Frase original: " + frase);
            System.out.println("Frase modificada: " + fraseModificada2);
        } else {
            System.out.println("La palabra '" + palabra + "' no se encuentra en la frase.");
        }
    }
    public void separarPalabras(String frase) {
        String[] palabrasEnFrase = frase.split(" ");
        System.out.println("Oracion original: " + frase);
        for (int i = 0; i < palabrasEnFrase.length; i++) {
            System.out.println(palabrasEnFrase[i]);
        }
    }
}
