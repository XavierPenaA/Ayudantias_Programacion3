import java.util.Arrays;
import java.util.Scanner;

public class Ordenamiento {
    public void ordenar() {
        String[] nombres = {
                "Juan Pérez",
                "Ana Sánchez",
                "Luis García",
                "María Rodríguez",
                "Pedro Martínez"
        };
        Scanner entrada = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("1. Ordenar de AZ");
            System.out.println("2. Ordenar de ZA");
            System.out.println("3. Volver al menu principal");
            opcion = entrada.nextInt();
            switch (opcion) {
                case 1:
                    ordenarAZ(nombres);
                    break;
                case 2:
                    ordenarZA(nombres);
                    break;
                case 3:
                    System.out.println("Volviendo al menu principal");
                    break;
            }
        } while (opcion != 3);
    }

    public void ordenarAZ(String[] array) {
        // Ordenar de A a Z y mostrar resultados
        Arrays.stream(array)
                .sorted()
                .forEach(System.out::println);
    }

    public void ordenarZA(String[] array) {
        // Ordenar de Z a A y mostrar resultados
        Arrays.stream(array)
                .sorted((s1, s2) -> s2.compareTo(s1)) // Comparador para invertir el orden
                .forEach(System.out::println);
    }
}
