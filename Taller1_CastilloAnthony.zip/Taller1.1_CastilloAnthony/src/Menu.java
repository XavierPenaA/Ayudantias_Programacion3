import java.util.Scanner;

public class Menu {

    Scanner sc = new Scanner(System.in);

    public String[] frases={"Hola Juan, cómo estas?","5 manzanas y 3 peras","Esta cadena no tiene números"};

    public void menuPrincipal() {
        int opc;
        do {
            System.out.println("Menu");
            System.out.println("1. Buscar letra");
            System.out.println("2. Buscar palabra");
            System.out.println("3. Salir");
            opc = sc.nextInt();
            sc.nextLine();
            switch (opc) {
                case 1:
                    this.buscarLetra();
                    break;
                case 2:
                    this.buscarPalabra();
                    break;
                case 3:
                    break;
                default:
                    System.out.println("Opcion Incorrecta");
                    break;
            }
        } while (opc != 3);
    }

    public void buscarLetra(){
        System.out.println("Ingrese una letra a buscar:");
        char letra = sc.nextLine().charAt(0);

        for (String frase : this.frases) {
            int cont = 0;
            for (int j = 0; j < frase.length(); j++) {
                if (frase.charAt(j) == letra) {
                    cont++;
                }
            }
            System.out.println("En la frase: \"" + frase + "\", el caracter '" + letra + "' apareció " + cont + " veces.");
        }
    }

    public void buscarPalabra(){
        System.out.println("Ingrese una palabra a buscar:");
        String palabra = sc.nextLine();

        for (String frase : this.frases) {
            String[] separacion = frase.split(" ");
            int cont = 0;
            for (String s : separacion) {
                String palabraLimpia = s.replaceAll("[^a-zA-Z]", "");  // Elimina caracteres no alfabéticos
                if (palabraLimpia.equalsIgnoreCase(palabra)) {
                    cont++;
                }
            }
            System.out.println("En la frase: \"" + frase + "\", la palabra '" + palabra + "' apareció " + cont + " veces.");
        }
    }
}
