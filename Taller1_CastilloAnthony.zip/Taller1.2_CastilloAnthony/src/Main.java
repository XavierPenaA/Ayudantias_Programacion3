import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        String palabra;
        String[] palabras= {"manzana", "banana", "naranja", "pera", "uva"};
        do{
            System.out.println("Ingrese un termino a buscar en el array de strings, o digite . para salir");
            palabra= sc.nextLine();
            for(int i=0; i< palabras.length;i++){
                if(palabras[i].contains(palabra)){
                    System.out.println(palabras[i]);
                }
            }
        }while (!palabra.equals("."));
    }
}