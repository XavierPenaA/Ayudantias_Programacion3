import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String frase = "juan tiene una bicicleta y juan tiene un coche, pero juan no tiene miedo.";
        System.out.println("La frase a trabajar es la siguiente:");
        System.out.println(frase);
        System.out.println("\nEliminacion de letras 'b'");
        String frase1= frase.replaceAll("b","");
        System.out.println(frase1);
        System.out.println("\nEliminacion de la palabra 'juan'");
        String frase2= frase.replaceAll("juan","");
        System.out.println(frase2);
        System.out.println("\nSeparar cada palabra de la frase y guardarlas en un array de strings");
        String[] palabras = frase.split(" ");
        for (int i=0; i<palabras.length;i++){
            System.out.println(palabras[i]);
        }
    }
}