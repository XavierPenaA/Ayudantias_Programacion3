import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        String[] nombres = {
                "Juan Pérez",
                "Ana Sánchez",
                "Luis García",
                "María Rodríguez",
                "Pedro Martínez"
        };
        System.out.println("Ordenamiento de nombres alfabeticamente ascendente");
        Arrays.sort(nombres);
        System.out.println(Arrays.toString(nombres));
        System.out.println("Ordenamiento de nombres alfabeticamente descendente");
        Arrays.sort(nombres, Comparator.reverseOrder());
        System.out.println(Arrays.toString(nombres));
    }
}