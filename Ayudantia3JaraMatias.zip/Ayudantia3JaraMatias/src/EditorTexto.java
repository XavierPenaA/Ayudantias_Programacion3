import java.util.Stack;

public class EditorTexto {
    private StringBuilder contenido;
    private Stack<String> pilaRehacer;
    private Stack <String> pilaDeshacer;

    public EditorTexto(){
        contenido = new StringBuilder();
        pilaRehacer = new Stack<>();
        pilaDeshacer = new Stack<>();
    }
    public void agregarTexto(String texto){
        pilaDeshacer.push(contenido.toString());
        contenido.append(texto);
        pilaRehacer.clear();

    }
    public void deshacer(){
        if(!pilaDeshacer.isEmpty()){
            pilaRehacer.push(contenido.toString());
            contenido = new StringBuilder(pilaDeshacer.pop());

        }else{
            System.out.println("No hay mas texto por deshacer");
        }
    }
    public void rehacer(){
        if(!pilaRehacer.isEmpty()){
            pilaDeshacer.push(contenido.toString());
            contenido = new StringBuilder(pilaRehacer.pop());
        }else{
            System.out.println("No hay mas texto para rehacer");
        }
    }
    public void mostrarContenido(){
        System.out.println("Contenido actual: " + contenido.toString());
    }


}
