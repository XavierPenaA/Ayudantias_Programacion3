import java.util.Scanner;

public class Menu {
    private EditorTexto cambiar = new EditorTexto();
    public void mostrarMenu() {
        Scanner entrada = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("Menu Principal:");
            System.out.println("1. Agregar texto");
            System.out.println("2. Deshacer");
            System.out.println("3. Rehacer");
            System.out.println("4. Mostrar contenido");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = entrada.nextInt();
            entrada.nextLine(); // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    ingresarTexto();
                    break;
                case 2:
                    cambiar.deshacer();
                    break;
                case 3:
                    cambiar.rehacer();
                    break;
                case 4:
                    cambiar.mostrarContenido();
                    break;
                case 5:
                    System.out.println("Saliendo del programa..");
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 5);
    }

    public void ingresarTexto(){
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese un texto: ");
        String text = entrada.nextLine();
        cambiar.agregarTexto(text);

    }
}
