import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
    Scanner entrada = new Scanner(System.in);
    public ManejoPersonas manejoPe = new ManejoPersonas();
    public ArrayList<Persona> personas = new ArrayList<>();

    public void menuPrincipal() {
        int op;

        do {
            System.out.println("\nMenu Principal");
            System.out.println("1.  Ingresar persona");
            System.out.println("2.  Mostrar personas");
            System.out.println("3.  Ordenar personas");
            System.out.println("4.  Buscar persona");
            System.out.println("5.  Comparar persona");
            System.out.println("6.  Salir");
            System.out.println("Ingrese la opcion <1-3>: ");
            op = entrada.nextInt();
            entrada.nextLine(); // Consumir el salto de línea después de nextInt()

            switch (op) {
                case 1:
                    manejoPe.ingresar();
                    break;
                case 2:
                    manejoPe.mostrar();
                    break;
                case 3:
                    manejoPe.ordenar();
                    break;
                case 4:
                    manejoPe.buscar();
                    break;
                case 5:
                    manejoPe.comparar();
                case 6:
                    System.out.println("TERMINO");
                    break;
            }
        } while (op != 6);
    }


}
