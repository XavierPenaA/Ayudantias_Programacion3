// Program para leer datos de varios tipos usando la clase Sacanner


import java.util.Scanner;

public class ScannerDemo {
    public static void main(String[] args) {
        // Declara el objeto e inicializar con
        // el objeto de entrada estandar predefinido

        Scanner sc = new Scanner(System.in);

        // entrada de una cadena
        String name  = sc.nextLine();
        // entrada de una caracter
        char gender = sc.next().charAt(0);

        // ebtrasa de datos numericos
        // bty, short y float

        int age = sc.nextInt();
        long mobileNo = sc.nextLong();
        double avarege = sc.nextDouble();

        // imprima los valores para verificar si la entrada
        // fue obtenida correctamente
        System.out.println("Nombre :" + name );
        System.out.println("Genero :" + gender );
        System.out.println("Edad :" + age );
        System.out.println("Telefono:" + mobileNo );
        System.out.println("Promedio :" + avarege );
    }
}