public class Main {
    public static void main(String[] args) {
        Menu m=new Menu();
        m.menuPrincipal();
    }
}
