import java.util.Scanner;

public class ScannerDemo2 {
    public static void main(String[] args) {
        // Declara el objeto e inicializar con
        // el objeto de entrada estandar predefinido

        Scanner sc = new Scanner(System.in);

       // Inicilizar la suma y el recuento
        // de los elementos de entrada
        int sum = 0, count = 0;

        // compruebe si un valor int esta disponible

        while(sc.hasNextInt()){
            // lee un valor int
            int num=sc.nextInt();
            sum+=num;
            count++;
        }
        int mean = sum/count;
        System.out.println("La medida es : " + mean );
    }
}
