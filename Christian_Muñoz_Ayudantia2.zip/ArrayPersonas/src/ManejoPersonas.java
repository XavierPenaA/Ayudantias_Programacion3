import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class ManejoPersonas {

    Scanner entrada = new Scanner(System.in);
    public ArrayList<Persona> personas = new ArrayList<>();
    public ArrayList encontrados = new ArrayList();

    public ManejoPersonas() {
        // Create an initial array of 5 personas
        personas.add(new Persona("1234567890", 25, "John", 'M'));
        personas.add(new Persona("2345678901", 30, "Jane", 'F'));
        personas.add(new Persona("3456789012", 22, "Alice", 'F'));
        personas.add(new Persona("4567890123", 28, "Bob", 'M'));
        personas.add(new Persona("4567890123", 28, "Bob", 'M'));
        personas.add(new Persona("5678901234", 35, "Charlie", 'M'));
        personas.add(new Persona("6789012345", 27, "Daniela", 'M'));
        personas.add(new Persona("7890123456", 31, "Edward", 'M'));
        personas.add(new Persona("8901234567", 24, "Fiona", 'F'));
        personas.add(new Persona("9012345678", 29, "George", 'M'));
        personas.add(new Persona("0123456789", 26, "Hannah", 'F'));
    }

    public void ingresar() {
        String nombre, mobile;
        char genero;
        int edad;
        System.out.println("Ingresar los datos de la persona\n");
        System.out.println("Ingrese el nombre: ");
        nombre = entrada.nextLine();
        System.out.println("Ingrese el genero: ");
        genero = entrada.nextLine().trim().toUpperCase().charAt(0);
        System.out.println("Ingrese la edad: ");
        edad = entrada.nextInt();
        entrada.nextLine(); // Consumir el salto de línea después de nextInt()
        System.out.println("Ingrese el mobile: ");
        mobile = entrada.nextLine();
        setPersonas(mobile, edad, nombre, genero);
        System.out.println("-----------------------------------");
    }

    public void setPersonas(String mobileNo, int edad, String nombre, char genero) {
        personas.add(new Persona(mobileNo, edad, nombre, genero));
    }


    public void mostrar() {

        switch (1) {
            case 1:
                System.out.printf("%-15s %-10s %-5s %-15s\n", "Nombre", "Genero", "Edad", "Mobile"); // Encabezados
                System.out.println("------------------------------------------------------------");

                for (int i = 0; i < personas.size(); i++) {
                    System.out.printf("%-15s %-10s %-5d %-15s\n",
                            personas.get(i).getNombre(),
                            personas.get(i).getGenero(),
                            personas.get(i).getEdad(),
                            personas.get(i).getMobileNo());
                }
                break;
            case 2:
                System.out.println("Otro metodo de acceder al arrar mediante otro tipo de recorrer, en el cual no es necesario utilizar.get(i)");

                for (Persona personas : personas) {
                    System.out.println("Nombre: " + personas.getNombre() +
                            ", Genero: " + personas.getGenero() +
                            ", Edad: " + personas.getEdad() +
                            ", Mobile: " + personas.getMobileNo());
                }
                break;
            case 3:
                System.out.println("Una manera mas facil de presentar en pantalla mediante el toString ");

                for (Persona personas : personas) {
                    System.out.println(personas);
                }
                break;

        }
    }

    public void ordenar() {
        int n = 0;
        int orden; // Para elegir entre ascendente o descendente

        do {
            System.out.println("||||||Ordenamiento de personas||||||");
            System.out.println("1. Ordenar por Nombre");
            System.out.println("2. Ordenar por Edad");
            System.out.println("3. Ordenar por Mobile");
            System.out.println("4. Ordenar por Genero");
            System.out.println("5. Salir al menu principal");
            n = entrada.nextInt();

            if (n != 5) {
                System.out.println("Elija el orden:");
                System.out.println("1. Ascendente");
                System.out.println("2. Descendente");
                orden = entrada.nextInt();
            } else {
                System.out.println("Saliendo al Menu Principal");
                break;
            }

            switch (n) {
                case 1: // Ordenar por Nombre
                    if (orden == 1) {
                        personas.sort(Comparator.comparing(Persona::getNombre));
                    } else {
                        personas.sort(Comparator.comparing(Persona::getNombre).reversed());
                    }
                    mostrar();
                    break;
                case 2: // Ordenar por Edad
                    if (orden == 1) {
                        personas.sort(Comparator.comparingInt(Persona::getEdad));
                    } else {
                        personas.sort(Comparator.comparingInt(Persona::getEdad).reversed());
                    }
                    mostrar();
                    break;
                case 3: // Ordenar por Mobile
                    if (orden == 1) {
                        personas.sort(Comparator.comparing(Persona::getMobileNo));
                    } else {
                        personas.sort(Comparator.comparing(Persona::getMobileNo).reversed());
                    }
                    mostrar();
                    break;
                case 4: // Ordenar por Genero
                    if (orden == 1) {
                        personas.sort(Comparator.comparing(Persona::getGenero));
                    } else {
                        personas.sort(Comparator.comparing(Persona::getGenero).reversed());
                    }
                    mostrar();
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (n != 5);
    }
    public void comparar() {
        if (personas.size() < 2) {
            System.out.println("No hay suficientes personas para comparar. Se necesitan al menos dos.");
            return;
        }

        System.out.println("Ingrese el índice de la primera persona (0 a " + (personas.size() - 1) + "): ");
        int indice1 = entrada.nextInt();
        System.out.println("Ingrese el índice de la segunda persona (0 a " + (personas.size() - 1) + "): ");
        int indice2 = entrada.nextInt();

        // Validar los índices ingresados
        if (indice1 < 0 || indice1 >= personas.size() || indice2 < 0 || indice2 >= personas.size()) {
            System.out.println("Índices inválidos. Intente nuevamente.");
            return;
        }

        Persona persona1 = personas.get(indice1);
        Persona persona2 = personas.get(indice2);

        // Comparar las dos personas
        if (persona1.equals(persona2)) {
            System.out.println("Las personas son iguales.");
        } else {
            System.out.println("Las personas son diferentes.");
        }
    }

    public void buscar() {
        int opcion = 0;
        do {
            System.out.println("||||||Busqueda personas||||||");
            System.out.println("1. Buscar por nombre");
            System.out.println("2. Buscar por edad");
            System.out.println("3. Buscar por mobile");
            System.out.println("4. Buscar por genero");
            System.out.println("5. Salir al menu principal");
            opcion = entrada.nextInt();
            entrada.nextLine(); // Consumir salto de línea

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el nombre: ");
                    String nombre = entrada.nextLine();
                    ArrayList<Integer> indicesNombre = buscarPorNombre(nombre);
                    imprimirIndices(indicesNombre);
                    break;
                case 2:
                    System.out.println("Ingrese la edad: ");
                    int edad = entrada.nextInt();
                    ArrayList<Integer> indicesEdad = buscarPorEdad(edad);
                    imprimirIndices(indicesEdad);
                    break;
                case 3:
                    System.out.println("Ingrese el mobile: ");
                    String mobile = entrada.nextLine();
                    ArrayList<Integer> indicesMobile = buscarPorMobile(mobile);
                    imprimirIndices(indicesMobile);
                    break;
                case 4:
                    System.out.println("Ingrese el genero (M/F): ");
                    char genero = entrada.nextLine().trim().toUpperCase().charAt(0); // Solo tomar el primer carácter
                    ArrayList<Integer> indicesGenero = buscarPorGenero(genero);
                    imprimirIndices(indicesGenero);
                    break;
                case 5:
                    System.out.println("Saliendo al Menu Principal");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 5);
    }

    // Buscar por nombre y devolver índices
    public ArrayList<Integer> buscarPorNombre(String nombre) {
        ArrayList<Integer> indices = new ArrayList<>();
        for (int i = 0; i < personas.size(); i++) {
            if (personas.get(i).getNombre().equalsIgnoreCase(nombre)) {
                indices.add(i);
            }
        }
        return indices;
    }

    // Buscar por edad y devolver índices
    public ArrayList<Integer> buscarPorEdad(int edad) {
        ArrayList<Integer> indices = new ArrayList<>();
        for (int i = 0; i < personas.size(); i++) {
            if (personas.get(i).getEdad() == edad) {
                indices.add(i);
            }
        }
        return indices;
    }

    // Buscar por mobile y devolver índices
    public ArrayList<Integer> buscarPorMobile(String mobile) {
        ArrayList<Integer> indices = new ArrayList<>();
        for (int i = 0; i < personas.size(); i++) {
            if (personas.get(i).getMobileNo().equals(mobile)) {
                indices.add(i);
            }
        }
        return indices;
    }

    // Buscar por género y devolver índices
    public ArrayList<Integer> buscarPorGenero(char genero) {
        ArrayList<Integer> indices = new ArrayList<>();
        for (int i = 0; i < personas.size(); i++) {
            if (personas.get(i).getGenero()==(genero)) {
                indices.add(i);
            }
        }
        return indices;
    }

    // Metodo auxiliar para imprimir los índices encontrados
    public void imprimirIndices(ArrayList<Integer> indices) {
        if (indices.isEmpty()) {
            System.out.println("No se encontraron coincidencias.");
        } else {
            System.out.println("Índices encontrados: " + indices);
            for (int index : indices) {
                Persona p = personas.get(index);
                System.out.printf("Índice: %d -> Nombre: %-15s Género: %-10s Edad: %-5d Mobile: %-15s\n",
                        index, p.getNombre(), p.getGenero(), p.getEdad(), p.getMobileNo());
            }
        }
    }

}



