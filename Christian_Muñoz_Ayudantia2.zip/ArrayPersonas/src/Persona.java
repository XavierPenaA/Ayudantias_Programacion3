public class Persona {
    private String nombre ;
    private char genero ;
    private int edad ;
    private String mobileNo ;


    public Persona(String mobileNo, int edad, String nombre, char genero) {
        this.mobileNo = mobileNo;
        this.edad = edad;
        this.nombre = nombre;
        this.genero = genero;
    }

    // una forma para obtener los valores que fueron guardados en esta clase y ya se creo un objeto

    @Override
    public String toString() {
        return
                "Nombre= " + nombre + '\'' +
                ", Genero=" + genero + '\'' +
                ", Edad=" + edad +
                ", MobileNo='" + mobileNo + '\'' ;
    }

    public String getNombre() {
        return nombre;
    }

    public char getGenero() {
        return genero;
    }

    public int getEdad() {
        return edad;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public boolean equals(Persona p){
        if (p.getNombre().equals(this.getNombre()) && p.getGenero()==(this.getGenero())
                    && p.getEdad()==this.getEdad() && p.getMobileNo().equals(this.getMobileNo()))
            return true;
        else return false;
    }
}
