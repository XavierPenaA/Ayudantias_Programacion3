import java.util.Scanner;
import java.util.Stack;

public class Menu {

    StringBuilder text = new StringBuilder("");
    Scanner input = new Scanner(System.in);
    Stack<String> undos = new Stack<String>();
    Stack<String> redos = new Stack<String>();


    public void show() {

        int opc;

        do {
            System.out.println("1. Add Text");
            System.out.println("2. Undo");
            System.out.println("3. Redo");
            System.out.println("4. Show Text");
            System.out.println("5. Exit");

            opc= input.nextInt();
            input.nextLine();

            switch (opc) {

                case 1:
                    option1();
                    break;
                case 2:
                    option2();
                    break;
                case 3:
                    option3();
                    break;
                case 4:
                    option4();
                    break;
                case 5:
                    option5();
                    break;
                default:
                    System.out.println("Wrong option");
                    break;
            }
        } while (opc!=5);
    }

    private void option1() {
        System.out.println("Enter your text: ");
        String newText = input.nextLine();
        text.append(newText);
        undos.push(newText);
        redos.clear();
    }
    private void option2() {
        if (!undos.isEmpty()) {
            String change = undos.pop();
            text = new StringBuilder(text.substring(0,text.length()-change.length()));
            redos.push(change);
        } else {
            System.out.println("Nothing to undo");
        }
    }
    private void option3() {
        if (!redos.isEmpty()) {
            String change = redos.pop();
            text = new StringBuilder(text.append(change));
            undos.push(change);
        } else {
            System.out.println("You're already in the last change");
        }
    }
    private void option4() {
        System.out.println("-------------------------------------");
        System.out.println(text.toString());
        System.out.println("-------------------------------------");
    }
    private void option5() {

    }
}
